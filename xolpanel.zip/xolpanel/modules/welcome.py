from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def menu(event):
	inline = [
[Button.inline("==> LOGIN <==","menu")]]
	sender = await event.get_sender()
	sender_id = sender.id
	sender_username = sender.username
	sender_firstname = sender.first_name
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("**⚠️Permission Not Allowed.!!**", alert=True)
		except:
			await event.reply("**⚠️Permission Not Allowed.!!**")
	elif val == "true":
		msg = f"""
**Haii.... Ini adalah bot panel khusus untuk server**
**Dan bot panel server anda siap untuk digunakan**

━━━━━━━━━━━━━━━━━━━
**🔰Name:** __{sender_firstname}__
**🔰User:** __@{sender_username}__
**🔰ID:** __{sender_id}__
━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
	else:
		await event.respond(f"** You Dont Have Access**")
