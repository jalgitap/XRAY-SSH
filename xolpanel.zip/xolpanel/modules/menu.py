from xolpanel import *
import socket

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" Menu SSH ","ssh"),
Button.inline(" Menu Vmess ","vmess")],
[Button.inline(" Menu Trojan ","trojan"),
Button.inline(" Menu Vless ","vless")],
[Button.inline(" Features ","setting")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("**⚠️Permission Not Allowed.!!**", alert=True)
		except:
			await event.reply("**⚠️Permission Not Allowed.!!**")
	elif val == "true":
		x = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		ip = requests.get("http://ipv4.icanhazip.com").text.strip("\n")
		exp = requests.get("http://raw.githubusercontent.com/jalgitap/izin/main/ipuser").text
		for i in list(filter(None, exp.split("\n"))):
			if i.split(" ")[3] == ip:
				exp = i.split(" ")[2]
				client = i.split(" ")[1]
				print(client)
		msg = f"""
×+━━━━━━━━━━━━━━━━━━━━━━+×
         **<<<• BOT MAIN MENU •>>>**
×+━━━━━━━━━━━━━━━━━━━━━━+×
**~DOMAIN      :** __{DOMAIN}__
**~BOT NAME  :** __Panel Server__
**~SERVICE      :** __Running__
**~VERSION     :** __New_2.0.1__
**~YOUR IP      :** __{ip}__
**~EXPIRED      :** __{exp}__
**~CLIENT        :** __{client}__
×+━━━━━━━━━━━━━━━━━━━━━━+×
**Regards From @WaanSuka_Turu**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
	else:
		await event.respond(f"** You Dont Have Access**")


