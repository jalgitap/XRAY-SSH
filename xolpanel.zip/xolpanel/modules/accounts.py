from xolpanel import *

@bot.on(events.CallbackQuery(data=b'accounts'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'list-accounts'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)