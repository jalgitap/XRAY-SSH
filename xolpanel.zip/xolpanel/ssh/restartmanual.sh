#!/bin/bash
read -p "Your Service Name : " user
sleep 0.5
systemctl restart "$user"