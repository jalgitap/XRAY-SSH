#!/bin/bash
NC='\e[0m'
red='\e[1;31m'
green='\e[0;32m'
yellow='\033[0;33m'
NMS="LOCKED"
NMM="UNLOCKED"
MYIP=$(wget -qO- ipinfo.io/ip)
echo -e "List Accounts SSH & OpenVPN"
echo -e "───────────────────────────"
while read expired; do
    AKUN="$(echo $expired | cut -d: -f1)"
    ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
    exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
    status="$(passwd -S $AKUN | awk '{print $2}')"
    if [[ $ID -ge 1000 ]]; then
        if [[ "$status" = "L" ]]; then
            echo -e "$AKUN  | $exp | $NMS"
        else
            echo -e "$AKUN  | $exp | $NMS"
        fi
    fi
done </etc/passwd
JUMLAH="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
echo -e "Accounts number : $JUMLAH user"
echo -e "───────────────────────────"

